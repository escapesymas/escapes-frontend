import React, { useState } from 'react';
import { User as UserIcon, MapPin, Save, ArrowLeft, Mail, Phone, Loader2, CheckCircle } from 'lucide-react';
import { User } from '../types';
import { updateCustomer } from '../services/woocommerce';

interface MyAccountProps {
  user: User;
  onBack: () => void;
  onUpdateUser: (user: User) => void;
}

export const MyAccount: React.FC<MyAccountProps> = ({ user, onBack, onUpdateUser }) => {
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  
  const [formData, setFormData] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    address: user.billing?.address_1 || '',
    city: user.billing?.city || '',
    zip: user.billing?.postcode || '',
    phone: user.billing?.phone || ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccessMsg('');

    const updatedData: Partial<User> = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      billing: {
        address_1: formData.address,
        city: formData.city,
        postcode: formData.zip,
        phone: formData.phone
      }
    };

    const success = await updateCustomer(user.id, updatedData);

    if (success) {
      // Update local state
      onUpdateUser({
        ...user,
        ...updatedData
      });
      setSuccessMsg('Perfil actualizado correctamente');
      setTimeout(() => setSuccessMsg(''), 3000);
    } else {
      alert("Error al actualizar el perfil");
    }
    setLoading(false);
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in min-h-screen">
      <div className="mb-8 flex items-center gap-4">
        <button onClick={onBack} className="text-zinc-500 hover:text-white transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-2xl md:text-3xl font-extrabold text-white uppercase italic flex items-center gap-3">
          Mi Cuenta <UserIcon className="w-6 h-6 text-racing-orange" />
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Info */}
        <div className="lg:col-span-1">
          <div className="bg-racing-carbon border border-zinc-800 p-6 rounded-sm text-center">
            <div className="w-24 h-24 bg-zinc-800 rounded-full mx-auto mb-4 overflow-hidden border-2 border-racing-orange">
              <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <h2 className="text-xl font-bold text-white mb-1">{user.username}</h2>
            <p className="text-zinc-500 text-sm mb-4">Piloto Oficial</p>
            <div className="bg-zinc-900/50 p-2 rounded text-xs text-zinc-400 font-mono">
              ID: RACER-{user.id}
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-racing-carbon border border-zinc-800 p-6 rounded-sm space-y-8">
            
            {/* Personal Info */}
            <div>
              <h3 className="text-white font-bold uppercase mb-4 tracking-wide border-b border-zinc-800 pb-2 flex items-center gap-2">
                <UserIcon className="w-4 h-4 text-racing-orange" /> Datos Personales
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Nombre</label>
                   <input required name="firstName" value={formData.firstName} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                </div>
                <div>
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Apellidos</label>
                   <input required name="lastName" value={formData.lastName} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                </div>
                <div className="md:col-span-2">
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Email</label>
                   <div className="relative">
                     <input required name="email" type="email" value={formData.email} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 pl-10 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                     <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3.5" />
                   </div>
                </div>
                <div className="md:col-span-2">
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Teléfono</label>
                   <div className="relative">
                     <input required name="phone" value={formData.phone} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 pl-10 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                     <Phone className="w-4 h-4 text-zinc-500 absolute left-3 top-3.5" />
                   </div>
                </div>
              </div>
            </div>

            {/* Address */}
            <div>
              <h3 className="text-white font-bold uppercase mb-4 tracking-wide border-b border-zinc-800 pb-2 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-racing-orange" /> Dirección de Envío
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Dirección</label>
                   <input required name="address" value={formData.address} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                </div>
                <div>
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Ciudad</label>
                   <input required name="city" value={formData.city} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                </div>
                <div>
                   <label className="block text-xs text-zinc-500 mb-1 uppercase font-bold">Código Postal</label>
                   <input required name="zip" value={formData.zip} onChange={handleChange} className="w-full bg-zinc-900 border border-zinc-700 p-3 text-white rounded-sm focus:border-racing-orange focus:outline-none" />
                </div>
              </div>
            </div>

            {/* Action */}
            <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
               {successMsg ? (
                 <div className="text-green-500 flex items-center gap-2 text-sm font-bold animate-pulse">
                   <CheckCircle className="w-5 h-5" /> {successMsg}
                 </div>
               ) : <span></span>}
               
               <button 
                type="submit" 
                disabled={loading}
                className="bg-racing-orange hover:bg-orange-600 text-white font-bold uppercase px-6 py-3 rounded-sm flex items-center gap-2 transition-colors disabled:opacity-50"
               >
                 {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                 Guardar Cambios
               </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};