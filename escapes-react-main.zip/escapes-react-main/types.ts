export interface Product {
  id: number;
  title: string;
  price: number;
  regularPrice: number; // Added: Original price before discount
  image: string;
  inStock: boolean;
  category: string;
  permalink?: string;
  attributes: { name: string; options: string[] }[]; // New field for dynamic filters
  description?: string;
  shortDescription?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface BikeSelection {
  brand: string;
  model: string;
  year: string;
}

export interface BikeDataStructure {
  brands: string[];
  models: Record<string, string[]>;
  years: string[];
}

// User & Auth
export interface User {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  token?: string; // JWT Token
  avatarUrl?: string;
  billing?: {
    address_1: string;
    city: string;
    postcode: string;
    phone: string;
  }
}

// WooCommerce specific types (subset)
export interface WooProduct {
  id: number;
  name: string;
  price: string;
  regular_price: string;
  stock_status: string;
  categories: { id: number; name: string }[];
  images: { id: number; src: string; alt: string }[];
  attributes: { id: number; name: string; options: string[] }[];
  permalink: string;
  description: string;
  short_description: string;
}

export interface WooCategory {
  id: number;
  name: string;
  parent: number;
  description: string;
  image: { src: string } | null;
  count: number;
}

export interface Category {
  id: number;
  name: string;
  parent: number;
  description: string;
  image: string;
  count: number;
}

// Order History Types
export interface Order {
  id: number;
  status: string;
  date_created: string;
  total: string;
  line_items: Array<{
    id: number;
    name: string;
    quantity: number;
    total: string;
  }>;
}

// Order Creation Types
export interface OrderPayload {
  payment_method: string;
  payment_method_title: string;
  set_paid: boolean;
  customer_id?: number; // Added for logged in users
  billing: {
    first_name: string;
    last_name: string;
    address_1: string;
    city: string;
    postcode: string;
    country: string;
    email: string;
    phone: string;
  };
  shipping: {
    first_name: string;
    last_name: string;
    address_1: string;
    city: string;
    postcode: string;
    country: string;
  };
  line_items: Array<{
    product_id: number;
    quantity: number;
  }>;
}

// --- FORUM TYPES ---
export interface ForumCategory {
  id: string;
  title: string;
  description: string;
  icon: any; // Lucide Icon
  topicCount: number;
}

export interface ForumTopic {
  id: number;
  categoryId: string;
  title: string;
  author: string;
  authorAvatar: string;
  date: string;
  views: number;
  replies: number;
  isPinned?: boolean;
  tags?: string[];
  content?: string;
}

export interface ForumReply {
  id: number;
  topicId: number;
  author: string;
  authorAvatar: string;
  authorRole?: string; // e.g., 'Admin', 'Moderator', 'Pro Racer'
  content: string;
  date: string;
  likes: number;
}

// --- GLOBAL DECLARATIONS ---
declare global {
  interface Window {
    gtag: (command: string, ...args: any[]) => void;
    dataLayer: any[];
  }
}